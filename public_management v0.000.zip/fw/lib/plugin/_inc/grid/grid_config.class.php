<?php
/**
 * Grid Configuracion
 * 
 *  
 * LICENSE: 
 *
 * @author     Herman Adrian Torres
 * @copyright  2014
 * @version    v0.4.1 21/08/2014          
 */
class GridConfig {
    const LINK_ID = 'link_id';
    const CHECKBOX = 'checkbox';
    const LINK_EDIT = 'link_edicion';
    const RADIO_EDIT = 'radio_edicion';
    
    const ITEMS_X_PAGINA = 25;

    public function __construct(){
    }
}
?>